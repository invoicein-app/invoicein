// ✅ FULL REPLACE FILE
// invoiceku/app/api/warehouses/[id]/stock-adjust/route.ts

export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { createServerClient } from "@supabase/ssr";
import crypto from "crypto";

function isUuid(v: any) {
  const s = String(v || "").trim();
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(s);
}
function num(v: any) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}
function isAdminRole(role: string) {
  const r = String(role || "").toLowerCase();
  return r === "admin" || r === "owner" || r === "super_admin";
}

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const warehouseId = String(id || "").trim();
  if (!isUuid(warehouseId)) return NextResponse.json({ error: "Invalid warehouse id" }, { status: 400 });

  const csAny: any = cookies() as any;
  const cookieStore: any = csAny?.then ? await csAny : csAny;

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => cookieStore.getAll(),
        setAll: (cookiesToSet) => {
          try {
            cookiesToSet.forEach(({ name, value, options }: any) => cookieStore.set(name, value, options));
          } catch {}
        },
      },
    }
  );

  // auth
  const { data: userRes, error: userErr } = await supabase.auth.getUser();
  if (userErr || !userRes?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const user = userRes.user;

  const body = await req.json().catch(() => null);
  if (!body) return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });

  const item_key = String(body.item_key || "").trim();
  const item_name = String(body.item_name || "").trim();
  const qty_delta = Math.floor(num(body.qty_delta));
  const note = body.note == null ? null : String(body.note || "").trim();

  if (!item_key) return NextResponse.json({ error: "item_key wajib" }, { status: 400 });
  if (!item_name) return NextResponse.json({ error: "item_name wajib" }, { status: 400 });
  if (!Number.isFinite(qty_delta) || qty_delta === 0) return NextResponse.json({ error: "qty_delta harus != 0" }, { status: 400 });

  // membership + role
  const { data: mem, error: memErr } = await supabase
    .from("memberships")
    .select("org_id, role, is_active")
    .eq("user_id", user.id)
    .eq("is_active", true)
    .limit(1)
    .maybeSingle();

  if (memErr) return NextResponse.json({ error: memErr.message }, { status: 400 });

  const orgId = String((mem as any)?.org_id || "");
  const role = String((mem as any)?.role || "");
  if (!orgId) return NextResponse.json({ error: "Org tidak ditemukan" }, { status: 400 });
  if (!isAdminRole(role)) return NextResponse.json({ error: "Forbidden (admin/owner only)" }, { status: 403 });

  // ensure warehouse belongs to org
  const { data: wh, error: whErr } = await supabase
    .from("warehouses")
    .select("id")
    .eq("id", warehouseId)
    .eq("org_id", orgId)
    .maybeSingle();

  if (whErr) return NextResponse.json({ error: whErr.message }, { status: 400 });
  if (!wh) return NextResponse.json({ error: "Gudang tidak ditemukan / beda org" }, { status: 404 });

  // read current on_hand
  const { data: bal, error: balErr } = await supabase
    .from("inventory_balances")
    .select("on_hand")
    .eq("org_id", orgId)
    .eq("warehouse_id", warehouseId)
    .eq("item_key", item_key)
    .maybeSingle();

  if (balErr) return NextResponse.json({ error: balErr.message }, { status: 400 });

  const cur = Math.max(0, Math.floor(num((bal as any)?.on_hand)));
  const next = Math.max(0, cur + qty_delta);

  // update balance dulu
  const { error: upErr } = await supabase
    .from("inventory_balances")
    .upsert(
      {
        org_id: orgId,
        warehouse_id: warehouseId,
        item_key,
        item_name,
        on_hand: next,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "org_id,warehouse_id,item_key" }
    );

  if (upErr) return NextResponse.json({ error: upErr.message }, { status: 400 });

  // ✅ ledger: ref_id & ref_line_id wajib NOT NULL
  const adjId = crypto.randomUUID();
  const adjLineId = crypto.randomUUID();

  const qty_in = qty_delta > 0 ? qty_delta : 0;
  const qty_out = qty_delta < 0 ? Math.abs(qty_delta) : 0;

  const { data: led, error: ledErr } = await supabase
    .from("stock_ledger")
    .insert({
      org_id: orgId,
      warehouse_id: warehouseId,
      ref_type: "ADJUSTMENT",
      ref_id: adjId,
      ref_line_id: adjLineId, // ✅ FIX: NOT NULL
      product_name: item_name,
      qty_in,
      qty_out,
      // kalau ada kolom note/notes di stock_ledger, baru isi di sini
    })
    .select("id, created_at")
    .single();

  if (ledErr) {
    // rollback balance (best effort)
    await supabase
      .from("inventory_balances")
      .upsert(
        {
          org_id: orgId,
          warehouse_id: warehouseId,
          item_key,
          item_name,
          on_hand: cur,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "org_id,warehouse_id,item_key" }
      );

    return NextResponse.json({ error: ledErr.message }, { status: 400 });
  }

  return NextResponse.json(
    {
      ok: true,
      warehouse_id: warehouseId,
      item_key,
      item_name,
      prev_on_hand: cur,
      next_on_hand: next,
      ledger_id: (led as any)?.id || null,
      ref_id: adjId,
      ref_line_id: adjLineId,
      created_at: (led as any)?.created_at || null,
      note: note || null,
    },
    { status: 200 }
  );
}