// ✅ BAGIAN D (FULL REPLACE)
// invoiceku/app/api/invoice/[id]/sent/route.ts
//
// POST /api/invoice/:id/sent
// - validasi invoice milik org user
// - panggil RPC public.post_invoice_sent(p_invoice_id uuid)
// - RPC akan: cek DN terakhir -> ambil warehouse -> stock- -> status sent
//
// NOTE:
// - Pastikan SQL function post_invoice_sent sudah dibuat.

export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { createServerClient } from "@supabase/ssr";

function isUuid(v: any) {
  const s = String(v || "").trim();
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(s);
}

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const invoiceId = String(id || "").trim();

  if (!isUuid(invoiceId)) {
    return NextResponse.json({ error: "Invalid invoice id" }, { status: 400 });
  }

  const csAny: any = cookies() as any;
  const cookieStore: any = csAny?.then ? await csAny : csAny;

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => cookieStore.getAll(),
        setAll: (cookiesToSet) => {
          try {
            cookiesToSet.forEach(({ name, value, options }: any) =>
              cookieStore.set(name, value, options)
            );
          } catch {}
        },
      },
    }
  );

  // auth
  const { data: userRes, error: userErr } = await supabase.auth.getUser();
  if (userErr || !userRes?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const user = userRes.user;

  // membership org gate
  const { data: mem, error: memErr } = await supabase
    .from("memberships")
    .select("org_id,is_active")
    .eq("user_id", user.id)
    .eq("is_active", true)
    .limit(1)
    .maybeSingle();

  if (memErr) return NextResponse.json({ error: memErr.message }, { status: 400 });
  if (!mem?.org_id) return NextResponse.json({ error: "Org tidak ditemukan" }, { status: 400 });

  const orgId = String((mem as any).org_id);

  // pastikan invoice milik org user
  const { data: inv, error: invErr } = await supabase
    .from("invoices")
    .select("id,org_id,status")
    .eq("id", invoiceId)
    .maybeSingle();

  if (invErr) return NextResponse.json({ error: invErr.message }, { status: 400 });
  if (!inv) return NextResponse.json({ error: "Invoice not found" }, { status: 404 });
  if (String((inv as any).org_id || "") !== orgId) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  // ✅ RPC: atomic
  const { data, error } = await supabase.rpc("post_invoice_sent", { p_invoice_id: invoiceId });
  if (error) {
    // error paling sering: belum ada delivery note / warehouse_id
    return NextResponse.json({ error: error.message }, { status: 400 });
  }

  return NextResponse.json({ ok: true, result: data }, { status: 200 });
}