// ✅ FULL REPLACE
// invoiceku/app/api/purchase-orders/create/route.ts
//
// UPDATE:
// - Terima items[].item_key (optional)
// - Kalau item_key kosong -> generate dari name (kayu basah -> kayu-basah)
// - Enforce unique key within PO (append -2, -3,...)
// - Insert ke purchase_order_items termasuk item_key
//
// Assumption: purchase_order_items punya kolom item_key (text)

export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { createServerClient } from "@supabase/ssr";
import { logActivity } from "@/lib/log-activity";

type Item = { name: string; item_key?: string; qty: number; price: number };

function num(v: any) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function safeDateOrNull(v: any) {
  const s = String(v || "").trim();
  if (!s) return null;
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  return null;
}

function computeSubtotal(items: Item[]) {
  return items.reduce(
    (a, it) => a + Math.max(0, Math.floor(num(it.qty))) * Math.max(0, Math.floor(num(it.price))),
    0
  );
}

function isUuid(v: any) {
  const s = String(v || "").trim();
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(s);
}

function toKey(raw: string) {
  const s = String(raw || "")
    .trim()
    .toLowerCase()
    .replace(/['"]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
  return s || "";
}

function uniqueKeyWithin(used: Set<string>, base: string) {
  let k = base || "item";
  if (!used.has(k)) return k;
  let n = 2;
  while (used.has(`${k}-${n}`)) n++;
  return `${k}-${n}`;
}

export async function POST(req: Request) {
  const csAny: any = cookies() as any;
  const cookieStore: any = csAny?.then ? await csAny : csAny;

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => cookieStore.getAll(),
        setAll: (cookiesToSet) => {
          try {
            cookiesToSet.forEach(({ name, value, options }: any) => cookieStore.set(name, value, options));
          } catch {}
        },
      },
    }
  );

  const { data: userRes, error: userErr } = await supabase.auth.getUser();
  if (userErr || !userRes?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const user = userRes.user;

  const body = await req.json().catch(() => null);
  if (!body) return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });

  const { po_date, expected_date, vendor_id, warehouse_id, show_ship_to_name, note, items } = body as any;

  if (!isUuid(vendor_id)) {
    return NextResponse.json({ error: "vendor_id wajib (UUID) dari master vendor." }, { status: 400 });
  }

  if (!isUuid(warehouse_id)) {
    return NextResponse.json({ error: "warehouse_id wajib (UUID) dari master gudang." }, { status: 400 });
  }

  if (!Array.isArray(items) || items.length === 0) {
    return NextResponse.json({ error: "Minimal 1 item." }, { status: 400 });
  }
  if (items.some((it: any) => !String(it?.name || "").trim())) {
    return NextResponse.json({ error: "Nama item tidak boleh kosong." }, { status: 400 });
  }

  const { data: membership, error: memErr } = await supabase
    .from("memberships")
    .select("org_id, role, is_active")
    .eq("user_id", user.id)
    .eq("is_active", true)
    .limit(1)
    .maybeSingle();

  if (memErr) return NextResponse.json({ error: memErr.message }, { status: 400 });
  if (!membership?.org_id) return NextResponse.json({ error: "Kamu belum punya organisasi aktif." }, { status: 400 });

  const orgId = String((membership as any).org_id);
  const actorRole = String((membership as any).role || "staff");

  const { data: vendor, error: vErr } = await supabase
    .from("vendors")
    .select("id, org_id, vendor_code, name, phone, email, address, note, is_active")
    .eq("id", String(vendor_id))
    .eq("org_id", orgId)
    .maybeSingle();

  if (vErr) return NextResponse.json({ error: vErr.message }, { status: 400 });
  if (!vendor) return NextResponse.json({ error: "Vendor tidak ditemukan (atau beda org)." }, { status: 404 });
  if (vendor.is_active === false) return NextResponse.json({ error: "Vendor sudah non-aktif." }, { status: 400 });

  const { data: wh, error: whErr } = await supabase
    .from("warehouses")
    .select("id, org_id, code, name, phone, address, is_active")
    .eq("id", String(warehouse_id))
    .eq("org_id", orgId)
    .maybeSingle();

  if (whErr) return NextResponse.json({ error: whErr.message }, { status: 400 });
  if (!wh) return NextResponse.json({ error: "Gudang tidak ditemukan (atau beda org)." }, { status: 404 });
  if (wh.is_active === false) return NextResponse.json({ error: "Gudang sudah non-aktif." }, { status: 400 });

  // ✅ normalize items + ensure item_key exists & unique within PO
  const used = new Set<string>();
  const normItems: Item[] = (items as any[]).map((it: any) => {
    const name = String(it?.name || "").trim();
    const rawKey = String(it?.item_key || "").trim().toLowerCase();
    const base = rawKey || toKey(name);
    const key = uniqueKeyWithin(used, base || "item");
    used.add(key);

    return {
      name,
      item_key: key,
      qty: Math.max(0, Math.floor(num(it?.qty))),
      price: Math.max(0, Math.floor(num(it?.price))),
    };
  });

  // safety
  if (normItems.some((x) => !x.item_key)) {
    return NextResponse.json({ error: "Gagal generate item_key." }, { status: 400 });
  }

  const subtotal = computeSubtotal(normItems);
  const total = subtotal;
  const showShipToName = typeof show_ship_to_name === "boolean" ? show_ship_to_name : true;

  const { data: po, error: poErr } = await supabase
    .from("purchase_orders")
    .insert({
      org_id: orgId,
      po_date: safeDateOrNull(po_date),
      expected_date: safeDateOrNull(expected_date),

      vendor_id: vendor.id,
      vendor_name: String(vendor.name || ""),
      vendor_phone: vendor.phone ? String(vendor.phone) : null,
      vendor_address: vendor.address ? String(vendor.address) : null,

      warehouse_id: wh.id,
      ship_to_name: String(wh.name || ""),
      ship_to_phone: wh.phone ? String(wh.phone) : null,
      ship_to_address: wh.address ? String(wh.address) : null,
      show_ship_to_name: showShipToName,

      note: note ? String(note) : null,
      status: "draft",
      subtotal,
      total,
      created_by: user.id,
    })
    .select("id, po_number, vendor_id, warehouse_id")
    .single();

  if (poErr) return NextResponse.json({ error: poErr.message }, { status: 400 });

  const payloadItems = normItems.map((it, idx) => ({
    purchase_order_id: po.id,
    name: it.name,
    item_key: it.item_key, // ✅ IMPORTANT
    qty: it.qty,
    price: it.price,
    sort_order: idx,
  }));

  const { error: itemErr } = await supabase.from("purchase_order_items").insert(payloadItems);

  if (itemErr) {
    await supabase.from("purchase_orders").delete().eq("id", po.id);
    return NextResponse.json({ error: itemErr.message }, { status: 400 });
  }

  await logActivity({
    org_id: orgId,
    actor_user_id: user.id,
    actor_role: actorRole,
    action: "po.create",
    entity_type: "purchase_order",
    entity_id: po.id,
    summary: `Create PO ${po.po_number || po.id}`,
    meta: {
      po_id: po.id,
      po_number: po.po_number ?? null,
      vendor_id: po.vendor_id,
      vendor_code: (vendor as any)?.vendor_code ?? null,
      vendor_name: String(vendor.name || ""),
      warehouse_id: po.warehouse_id,
      ship_to_name: String((wh as any)?.name || ""),
      items_count: payloadItems.length,
      subtotal,
      total,
      status: "draft",
    },
  });

  return NextResponse.json(
    {
      id: po.id,
      po_number: po.po_number ?? null,
      vendor_id: po.vendor_id,
      vendor_code: (vendor as any)?.vendor_code ?? null,
      warehouse_id: po.warehouse_id,
      subtotal,
      total,
    },
    { status: 200 }
  );
}