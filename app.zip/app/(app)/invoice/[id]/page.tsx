// ✅ FULL REPLACE
// invoiceku/app/invoice/[id]/page.tsx
// + Tambah tombol "Send Invoice"
// + Tombol akan call /api/invoice/[id]/sent
//
// NOTE:
// - Send akan disable kalau status sudah sent / paid / cancelled
// - Cancel tetap ada seperti sebelumnya

export const runtime = "nodejs";

import { cookies } from "next/headers";
import { createServerClient } from "@supabase/ssr";

import BackButton from "../back-button-client";
import PaymentsClient from "../payments-client";
import PdfButtonClient from "../pdf-button-client";
import SjButtonClient from "../sj-button-client";
import DotmatrixButtonClient from "../dotmatrix-button-client";
import CancelInvoiceButtonClient from "../cancel-invoice-button-client";
import SentInvoiceButtonClient from "../sent-invoice-button-client";

type PageProps = {
  params: Promise<{ id: string }>;
};

function rupiah(n: number) {
  const safe = Number.isFinite(n) ? n : 0;
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0,
  }).format(safe);
}

function clampPercent(v: any) {
  const n = Number(v ?? 0);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(100, Math.floor(n)));
}

function safeInt(v: any) {
  const n = Math.floor(Number(v ?? 0));
  return Number.isFinite(n) ? n : 0;
}

function fmtDate(iso: any) {
  if (!iso) return "-";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "-";
  return d.toLocaleDateString("id-ID", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
}

export default async function InvoiceViewPage({ params }: PageProps) {
  const { id } = await params;

  const cookieStore = await cookies();
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => cookieStore.getAll(),
        setAll: (cookiesToSet) => {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            );
          } catch {}
        },
      },
    }
  );

  const { data: userRes } = await supabase.auth.getUser();
  const user = userRes.user;

  if (!user) {
    return (
      <div style={{ padding: 24 }}>
        <h2>Kamu belum login</h2>
      </div>
    );
  }

  const { data: invoice, error: invErr } = await supabase
    .from("invoices")
    .select(
      `
      id,
      invoice_number,
      invoice_date,
      due_date,
      status,
      customer_name,
      customer_phone,
      customer_address,
      note,
      discount_type,
      discount_value,
      tax_value,
      amount_paid,
      quotation_id,
      warehouse_id,
      sent_at
    `
    )
    .eq("id", id)
    .single();

  if (invErr || !invoice) {
    return (
      <div style={{ padding: 24 }}>
        <h2>Invoice tidak ditemukan / tidak punya akses</h2>
        <div style={{ marginTop: 8, color: "#666" }}>{invErr?.message}</div>
      </div>
    );
  }

  const { data: items } = await supabase
    .from("invoice_items")
    .select("id, name, item_key, qty, price, sort_order")
    .eq("invoice_id", id)
    .order("sort_order", { ascending: true });

  const subtotal =
    (items || []).reduce(
      (acc, it: any) => acc + Number(it.qty || 0) * Number(it.price || 0),
      0
    ) || 0;

  const dtRaw = String((invoice as any).discount_type || "percent").toLowerCase();
  const discountType: "percent" | "amount" =
    dtRaw === "amount" || dtRaw === "fixed" ? "amount" : "percent";

  const rawDiscountValue = safeInt((invoice as any).discount_value);
  const discPct = discountType === "percent" ? clampPercent(rawDiscountValue) : 0;

  const discount =
    discountType === "percent"
      ? Math.max(0, Math.floor(subtotal * (discPct / 100)))
      : Math.max(0, Math.min(subtotal, Math.floor(rawDiscountValue)));

  const taxPct = clampPercent((invoice as any).tax_value);

  const afterDisc = Math.max(0, subtotal - discount);
  const tax = Math.max(0, Math.floor(afterDisc * (taxPct / 100)));
  const grandTotal = Math.max(0, afterDisc + tax);

  const amountPaid = Math.max(0, Number((invoice as any).amount_paid || 0));
  const remaining = Math.max(0, grandTotal - amountPaid);

  let payLabel = "UNPAID";
  let payBg = "#fff7ed";
  let payBorder = "#fdba74";
  let payColor = "#9a3412";

  if (remaining <= 0 && grandTotal > 0) {
    payLabel = "PAID";
    payBg = "#ecfdf5";
    payBorder = "#6ee7b7";
    payColor = "#065f46";
  } else if (amountPaid > 0 && remaining > 0) {
    payLabel = "PARTIAL";
    payBg = "#eff6ff";
    payBorder = "#93c5fd";
    payColor = "#1e3a8a";
  }

  const discountLabel =
    discountType === "percent" ? `Diskon (${discPct}%)` : "Diskon";

  const docStatus = String((invoice as any).status || "").toLowerCase();
  const canCancel =
    amountPaid <= 0 &&
    docStatus !== "paid" &&
    docStatus !== "cancelled";

  return (
    <div style={{ padding: 24, maxWidth: 960, margin: "0 auto" }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          gap: 12,
          flexWrap: "wrap",
        }}
      >
        <div
          style={{
            display: "flex",
            gap: 8,
            flexWrap: "wrap",
            alignItems: "center",
          }}
        >
          <BackButton />

          <PdfButtonClient href={`/api/invoice/pdf/${id}`} />
          <DotmatrixButtonClient href={`/api/invoice/pdf-dotmatrix/${id}`} />

          <SentInvoiceButtonClient
            invoiceId={id}
            invoiceNumber={(invoice as any).invoice_number ?? null}
            currentStatus={(invoice as any).status ?? null}
          />

          <CancelInvoiceButtonClient
            invoiceId={id}
            invoiceNumber={(invoice as any).invoice_number ?? null}
            disabled={!canCancel}
          />

          <div>
            <div style={{ fontSize: 22, fontWeight: 800 }}>
              Invoice {(invoice as any).invoice_number || "(tanpa nomor)"}
            </div>
            <div style={{ color: "#666", marginTop: 4 }}>
              Tanggal: {(invoice as any).invoice_date ? fmtDate((invoice as any).invoice_date) : "-"}
              {" • "}
              Jatuh tempo: {(invoice as any).due_date ? fmtDate((invoice as any).due_date) : "-"}
              {" • "}
              Status dokumen: {(invoice as any).status || "-"}
            </div>
          </div>

          <div
            style={{
              alignSelf: "center",
              padding: "6px 10px",
              borderRadius: 999,
              background: payBg,
              border: `1px solid ${payBorder}`,
              color: payColor,
              fontWeight: 800,
              fontSize: 12,
              letterSpacing: 0.4,
              whiteSpace: "nowrap",
              height: 32,
              display: "inline-flex",
              alignItems: "center",
            }}
          >
            {payLabel}
          </div>
        </div>
      </div>

      <div
        style={{
          marginTop: 16,
          padding: 14,
          borderRadius: 14,
          border: "1px solid #eee",
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
          gap: 12,
        }}
      >
        <div style={{ padding: 12, borderRadius: 12, border: "1px solid #f1f1f1" }}>
          <div style={{ fontSize: 12, color: "#666" }}>Total Invoice</div>
          <div style={{ fontSize: 18, fontWeight: 800 }}>{rupiah(grandTotal)}</div>
        </div>

        <div style={{ padding: 12, borderRadius: 12, border: "1px solid #f1f1f1" }}>
          <div style={{ fontSize: 12, color: "#666" }}>Terbayar</div>
          <div style={{ fontSize: 18, fontWeight: 800 }}>{rupiah(amountPaid)}</div>
        </div>

        <div style={{ padding: 12, borderRadius: 12, border: "1px solid #f1f1f1" }}>
          <div style={{ fontSize: 12, color: "#666" }}>Sisa Belum Dibayar</div>
          <div style={{ fontSize: 18, fontWeight: 800 }}>{rupiah(remaining)}</div>
        </div>
      </div>

      <div style={{ marginTop: 16, padding: 14, borderRadius: 14, border: "1px solid #eee" }}>
        <div style={{ fontWeight: 800, marginBottom: 8 }}>Customer</div>
        <div style={{ display: "grid", gap: 4 }}>
          <div>
            <span style={{ color: "#666" }}>Nama:</span> {(invoice as any).customer_name || "-"}
          </div>
          <div>
            <span style={{ color: "#666" }}>Telepon:</span> {(invoice as any).customer_phone || "-"}
          </div>
          <div>
            <span style={{ color: "#666" }}>Alamat:</span> {(invoice as any).customer_address || "-"}
          </div>
          <div>
            <span style={{ color: "#666" }}>Gudang:</span>{" "}
            {(invoice as any).warehouse_id || "-"}
          </div>
          <div>
            <span style={{ color: "#666" }}>Sent At:</span>{" "}
            {(invoice as any).sent_at ? fmtDate((invoice as any).sent_at) : "-"}
          </div>
        </div>
      </div>

      <div style={{ marginTop: 16, padding: 14, borderRadius: 14, border: "1px solid #eee" }}>
        <div style={{ fontWeight: 800, marginBottom: 8 }}>Items</div>

        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ textAlign: "left", color: "#666" }}>
                <th style={{ padding: "10px 8px", borderBottom: "1px solid #eee" }}>Nama</th>
                <th style={{ padding: "10px 8px", borderBottom: "1px solid #eee", width: 180 }}>Key</th>
                <th style={{ padding: "10px 8px", borderBottom: "1px solid #eee", width: 100 }}>Qty</th>
                <th style={{ padding: "10px 8px", borderBottom: "1px solid #eee", width: 160 }}>Harga</th>
                <th style={{ padding: "10px 8px", borderBottom: "1px solid #eee", width: 180 }}>Total</th>
              </tr>
            </thead>
            <tbody>
              {(items || []).map((it: any) => {
                const lineTotal = Number(it.qty || 0) * Number(it.price || 0);
                return (
                  <tr key={it.id}>
                    <td style={{ padding: "10px 8px", borderBottom: "1px solid #f3f3f3" }}>{it.name}</td>
                    <td
                      style={{
                        padding: "10px 8px",
                        borderBottom: "1px solid #f3f3f3",
                        fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
                      }}
                    >
                      {it.item_key || "-"}
                    </td>
                    <td style={{ padding: "10px 8px", borderBottom: "1px solid #f3f3f3" }}>{Number(it.qty || 0)}</td>
                    <td style={{ padding: "10px 8px", borderBottom: "1px solid #f3f3f3" }}>{rupiah(Number(it.price || 0))}</td>
                    <td style={{ padding: "10px 8px", borderBottom: "1px solid #f3f3f3" }}>{rupiah(lineTotal)}</td>
                  </tr>
                );
              })}

              {!items?.length && (
                <tr>
                  <td colSpan={5} style={{ padding: 12, color: "#666" }}>
                    Belum ada item.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div style={{ marginTop: 12, display: "grid", gap: 6, maxWidth: 420, marginLeft: "auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span style={{ color: "#666" }}>Subtotal</span>
            <b>{rupiah(subtotal)}</b>
          </div>

          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span style={{ color: "#666" }}>{discountLabel}</span>
            <b>- {rupiah(discount)}</b>
          </div>

          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span style={{ color: "#666" }}>Pajak ({taxPct}%)</span>
            <b>{rupiah(tax)}</b>
          </div>

          <div style={{ height: 1, background: "#eee", margin: "6px 0" }} />

          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 16 }}>
            <span style={{ fontWeight: 800 }}>Grand Total</span>
            <span style={{ fontWeight: 800 }}>{rupiah(grandTotal)}</span>
          </div>
        </div>
      </div>

      <div style={{ marginTop: 16, padding: 14, borderRadius: 14, border: "1px solid #eee" }}>
        <div style={{ fontWeight: 800, marginBottom: 6 }}>Catatan</div>
        <div style={{ color: "#333" }}>{(invoice as any).note || "-"}</div>
      </div>

      <div style={{ marginTop: 16, display: "flex", gap: 12, alignItems: "flex-start", flexWrap: "wrap" }}>
        <div style={{ marginTop: 16, display: "flex", gap: 12, flexWrap: "wrap", alignItems: "flex-start" }}>
          <SjButtonClient invoiceId={id} />

          <div style={{ flex: "1 1 740px", minWidth: 320 }}>
            <PaymentsClient invoiceId={id} />
          </div>
        </div>
      </div>
    </div>
  );
}